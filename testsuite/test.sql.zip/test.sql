# ************************************************************
# Sequel Pro SQL dump
# Version 5446
#
# https://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: localhost (MySQL 5.5.5-10.4.6-MariaDB)
# Database: quid5
# Generation Time: 2019-09-09 13:31:33 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
SET NAMES utf8mb4;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table email
# ------------------------------------------------------------

DROP TABLE IF EXISTS `email`;

CREATE TABLE `email` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) DEFAULT NULL,
  `type` tinyint(1) DEFAULT NULL,
  `key` varchar(100) DEFAULT NULL,
  `name_fr` varchar(250) DEFAULT NULL,
  `name_en` varchar(250) DEFAULT NULL,
  `content_fr` text DEFAULT NULL,
  `content_en` text DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

LOCK TABLES `email` WRITE;
/*!40000 ALTER TABLE `email` DISABLE KEYS */;

INSERT INTO `email` (`id`, `active`, `type`, `key`, `name_fr`, `name_en`, `content_fr`, `content_en`, `userAdd`, `dateAdd`, `userModify`, `dateModify`)
VALUES
	(1,1,2,'resetPassword','Password reset [subject]','Password reset [subject]','FR Lorem ipsum [password] [uri]\n\nThanks,\n[domain]','EN Lorem ipsum [password] [uri]\n\nThanks,\n[domain]',NULL,NULL,NULL,NULL),
	(2,1,2,'registerConfirm','Register confirm','Register confirm','BLA','BLA',NULL,NULL,NULL,NULL);

/*!40000 ALTER TABLE `email` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table lang
# ------------------------------------------------------------

DROP TABLE IF EXISTS `lang`;

CREATE TABLE `lang` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` text DEFAULT NULL,
  `active` tinyint(1) DEFAULT 1,
  `key` varchar(100) DEFAULT NULL,
  `content_fr` text DEFAULT NULL,
  `content_en` text DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `typeKey` (`type`(10),`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table log
# ------------------------------------------------------------

DROP TABLE IF EXISTS `log`;

CREATE TABLE `log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` int(11) DEFAULT NULL,
  `context` varchar(100) DEFAULT NULL,
  `request` text DEFAULT NULL,
  `json` text DEFAULT NULL,
  `session_id` int(11) DEFAULT NULL,
  `userCommit` int(11) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table logCron
# ------------------------------------------------------------

DROP TABLE IF EXISTS `logCron`;

CREATE TABLE `logCron` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` int(11) DEFAULT NULL,
  `context` varchar(100) DEFAULT NULL,
  `json` text DEFAULT NULL,
  `session_id` int(11) DEFAULT NULL,
  `userCommit` int(11) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table logEmail
# ------------------------------------------------------------

DROP TABLE IF EXISTS `logEmail`;

CREATE TABLE `logEmail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) DEFAULT NULL,
  `context` varchar(100) DEFAULT NULL,
  `json` text DEFAULT NULL,
  `request` text DEFAULT NULL,
  `session_id` int(11) DEFAULT NULL,
  `userCommit` int(11) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table logError
# ------------------------------------------------------------

DROP TABLE IF EXISTS `logError`;

CREATE TABLE `logError` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(11) DEFAULT NULL,
  `context` varchar(100) DEFAULT NULL,
  `error` text DEFAULT NULL,
  `request` text DEFAULT NULL,
  `session_id` int(11) DEFAULT NULL,
  `userCommit` int(11) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table logHttp
# ------------------------------------------------------------

DROP TABLE IF EXISTS `logHttp`;

CREATE TABLE `logHttp` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` int(11) DEFAULT NULL,
  `context` varchar(100) DEFAULT NULL,
  `request` text DEFAULT NULL,
  `json` text DEFAULT NULL,
  `session_id` int(11) DEFAULT NULL,
  `userCommit` int(11) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table logSql
# ------------------------------------------------------------

DROP TABLE IF EXISTS `logSql`;

CREATE TABLE `logSql` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` int(11) DEFAULT NULL,
  `context` varchar(100) DEFAULT NULL,
  `request` text DEFAULT NULL,
  `json` text DEFAULT NULL,
  `session_id` int(11) DEFAULT NULL,
  `userCommit` int(11) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table main
# ------------------------------------------------------------

DROP TABLE IF EXISTS `main`;

CREATE TABLE `main` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name_en` varchar(100) DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table ormCell
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ormCell`;

CREATE TABLE `ormCell` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) DEFAULT 2,
  `name` varchar(100) NOT NULL DEFAULT '',
  `date` int(11) DEFAULT NULL,
  `integer` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_ids` text DEFAULT NULL,
  `media` text DEFAULT NULL,
  `thumbnail` text DEFAULT NULL,
  `content` text DEFAULT NULL,
  `float` float DEFAULT NULL,
  `enum` int(11) DEFAULT NULL,
  `set` text DEFAULT NULL,
  `vimeo` text DEFAULT NULL,
  `medias` text DEFAULT NULL,
  `thumbnails` text DEFAULT NULL,
  `googleMaps` text DEFAULT NULL,
  `dateStart` int(11) DEFAULT NULL,
  `dateEnd` int(11) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) NOT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table ormCells
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ormCells`;

CREATE TABLE `ormCells` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) DEFAULT 6,
  `name_en` varchar(100) DEFAULT 'LOL',
  `email` varchar(250) DEFAULT NULL,
  `date` int(11) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table ormCol
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ormCol`;

CREATE TABLE `ormCol` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) DEFAULT NULL,
  `date` int(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT 'lol2',
  `email` varchar(100) DEFAULT 'lol',
  `phone` varchar(100) DEFAULT NULL,
  `slug_fr` varchar(100) DEFAULT NULL,
  `def` varchar(100) NOT NULL DEFAULT 'James',
  `wysiwyg` text DEFAULT NULL,
  `googleMaps` text DEFAULT NULL,
  `myVideo` text DEFAULT NULL,
  `myRelation` int(11) DEFAULT NULL,
  `relationRange` int(11) DEFAULT NULL,
  `relationLang` int(11) DEFAULT NULL,
  `relationCall` int(11) DEFAULT NULL,
  `float` float DEFAULT NULL,
  `media` text DEFAULT NULL,
  `medias` text DEFAULT NULL,
  `storage` text DEFAULT NULL,
  `multi` text DEFAULT NULL,
  `check` text DEFAULT NULL,
  `form` text DEFAULT NULL,
  `rangeInt` int(11) DEFAULT NULL,
  `other` text DEFAULT NULL,
  `other2` text DEFAULT NULL,
  `dateStart` int(11) DEFAULT NULL,
  `dateEnd` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_ids` text DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) unsigned DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `date` (`date`,`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table ormCols
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ormCols`;

CREATE TABLE `ormCols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) DEFAULT 1,
  `name_en` varchar(100) DEFAULT 'LOL',
  `email` varchar(250) DEFAULT NULL,
  `date` int(11) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table ormDb
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ormDb`;

CREATE TABLE `ormDb` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name_en` varchar(250) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

LOCK TABLES `ormDb` WRITE;
/*!40000 ALTER TABLE `ormDb` DISABLE KEYS */;

INSERT INTO `ormDb` (`id`, `name_en`, `dateAdd`)
VALUES
	(1,'james',10),
	(2,'james2',11),
	(3,'james3',10);

/*!40000 ALTER TABLE `ormDb` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table ormRow
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ormRow`;

CREATE TABLE `ormRow` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) DEFAULT NULL,
  `name_en` varchar(100) DEFAULT NULL,
  `name_de` varchar(100) DEFAULT NULL,
  `content_en` text DEFAULT NULL,
  `date` int(11) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table ormRows
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ormRows`;

CREATE TABLE `ormRows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

LOCK TABLES `ormRows` WRITE;
/*!40000 ALTER TABLE `ormRows` DISABLE KEYS */;

INSERT INTO `ormRows` (`id`, `active`, `name`, `userAdd`, `dateAdd`, `userModify`, `dateModify`)
VALUES
	(2,2,'james3',21,20,23,22),
	(1,1,'james',11,10,13,12),
	(3,3,'james2',31,30,33,32);

/*!40000 ALTER TABLE `ormRows` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table ormRowsIndex
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ormRowsIndex`;

CREATE TABLE `ormRowsIndex` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `activez` tinyint(1) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table ormRowsIndexDeep
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ormRowsIndexDeep`;

CREATE TABLE `ormRowsIndexDeep` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `activez` tinyint(1) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table ormSql
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ormSql`;

CREATE TABLE `ormSql` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table ormTable
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ormTable`;

CREATE TABLE `ormTable` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) DEFAULT 1,
  `name_en` varchar(100) DEFAULT 'LOL',
  `name_fr` varchar(100) DEFAULT NULL,
  `content_en` text DEFAULT NULL,
  `test_ok` int(11) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `date` int(11) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table ormTables
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ormTables`;

CREATE TABLE `ormTables` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table ormTableSibling
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ormTableSibling`;

CREATE TABLE `ormTableSibling` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `activez` tinyint(1) DEFAULT NULL,
  `name_en` varchar(100) DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `content_en` text DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table queueEmail
# ------------------------------------------------------------

DROP TABLE IF EXISTS `queueEmail`;

CREATE TABLE `queueEmail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) DEFAULT NULL,
  `context` varchar(100) DEFAULT NULL,
  `json` text DEFAULT NULL,
  `session_id` int(11) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table session
# ------------------------------------------------------------

DROP TABLE IF EXISTS `session`;

CREATE TABLE `session` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `context` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `sid` varchar(100) DEFAULT NULL,
  `data` text DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

LOCK TABLES `session` WRITE;
/*!40000 ALTER TABLE `session` DISABLE KEYS */;

INSERT INTO `session` (`id`, `context`, `name`, `sid`, `data`, `count`, `user_id`, `userAdd`, `dateAdd`, `userModify`, `dateModify`)
VALUES
	(1,'{\"env\":\"dev\",\"type\":\"assert\",\"lang\":\"en\"}','assert','assert-mfqt1min1l58p8vnqims9juq2t1mfv4gthi7bi97','a:19:{s:5:\"flash\";C:15:\"Quid\\Core\\Flash\":57:{a:3:{s:4:\"data\";a:0:{}s:5:\"cache\";a:0:{}s:5:\"index\";i:0;}}s:7:\"history\";C:24:\"Quid\\Core\\RequestHistory\":57:{a:3:{s:4:\"data\";a:0:{}s:5:\"cache\";a:0:{}s:5:\"index\";i:0;}}s:7:\"timeout\";C:17:\"Quid\\Main\\Timeout\":57:{a:3:{s:4:\"data\";a:0:{}s:5:\"cache\";a:0:{}s:5:\"index\";i:0;}}s:3:\"com\";C:13:\"Quid\\Core\\Com\":163:{a:5:{s:4:\"type\";a:3:{i:0;s:3:\"neg\";i:1;s:3:\"pos\";i:2;s:7:\"neutral\";}s:4:\"data\";a:0:{}s:5:\"cache\";a:0:{}s:5:\"index\";i:0;s:6:\"option\";a:1:{s:7:\"default\";s:3:\"neg\";}}}s:3:\"nav\";C:13:\"Quid\\Core\\Nav\":57:{a:3:{s:4:\"data\";a:0:{}s:5:\"cache\";a:0:{}s:5:\"index\";i:0;}}s:4:\"user\";a:2:{s:3:\"uid\";i:2;s:10:\"permission\";i:80;}s:3:\"env\";s:3:\"dev\";s:4:\"type\";s:6:\"assert\";s:7:\"version\";s:12:\"1.0.1-5.27.0\";s:6:\"expire\";i:1570626345;s:9:\"timestamp\";a:2:{s:7:\"current\";i:1568034348;s:8:\"previous\";N;}s:12:\"requestCount\";i:1;s:9:\"userAgent\";s:119:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/12.1.2 Safari/605.1.15\";s:2:\"ip\";s:9:\"127.0.0.1\";s:11:\"fingerprint\";N;s:4:\"lang\";s:2:\"en\";s:4:\"csrf\";s:40:\"p0qDdcseMqzMsuDqvuIP033Ulkdve7lO4fltyu3R\";s:7:\"captcha\";N;s:8:\"remember\";N;}',1,2,1,1568034348,2,1568034350);

/*!40000 ALTER TABLE `session` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) DEFAULT NULL,
  `role` tinyint(1) DEFAULT 20,
  `username` varchar(250) DEFAULT NULL,
  `password` varchar(250) DEFAULT NULL,
  `passwordReset` varchar(250) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `timezone` int(11) DEFAULT NULL,
  `dateLogin` int(11) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;

INSERT INTO `user` (`id`, `active`, `role`, `username`, `password`, `passwordReset`, `email`, `timezone`, `dateLogin`, `userAdd`, `dateAdd`, `userModify`, `dateModify`)
VALUES
	(1,1,1,'nobody','$2y$11$8nFxo4CJfdzkT3ljRTrnAeYVsRIWDNlb/UDh.yRyuA9DN0GqZzMfe',NULL,'nobody@quid.com',NULL,1518037067,1,1384403273,1,1384403273),
	(2,1,80,'admin','$2y$11$8nFxo4CJfdzkT3ljRTrnAeYVsRIWDNlb/UDh.yRyuA9DN0GqZzMfe',NULL,'administrator@quid.com',NULL,1518037067,2,1384403273,2,1384403273),
	(3,1,20,'user','$2y$04$ab4e8A.Jw.4z9aq0q3UEC.0/rYjyPilfU03nUTYUVhnmpUIlBZkPe',NULL,'user@quid.com',NULL,1568034348,3,1384403273,3,1568034348),
	(4,0,20,'inactive','$2y$11$8nFxo4CJfdzkT3ljRTrnAeYVsRIWDNlb/UDh.yRyuA9DN0GqZzMfe',NULL,'inactive@quid.com',NULL,1519241542,4,1384403273,4,1519241545);

/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
