# ************************************************************
# Sequel Pro SQL dump
# Version 5446
#
# https://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: localhost (MySQL 5.5.5-10.4.6-MariaDB)
# Database: project
# Generation Time: 2020-04-02 21:10:32 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
SET NAMES utf8mb4;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table contact
# ------------------------------------------------------------

DROP TABLE IF EXISTS `contact`;

CREATE TABLE `contact` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `context` varchar(100) DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `session_id` int(11) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table email
# ------------------------------------------------------------

DROP TABLE IF EXISTS `email`;

CREATE TABLE `email` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) DEFAULT 1,
  `type` tinyint(1) DEFAULT NULL,
  `key` varchar(100) DEFAULT NULL,
  `name_en` varchar(250) DEFAULT NULL,
  `content_en` text DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

LOCK TABLES `email` WRITE;
/*!40000 ALTER TABLE `email` DISABLE KEYS */;

INSERT INTO `email` (`id`, `active`, `type`, `key`, `name_en`, `content_en`, `userAdd`, `dateAdd`, `userModify`, `dateModify`)
VALUES
	(1,1,1,'userWelcome','Welcome','[name],\r\n\r\nYour account is ready to use.\r\n\r\nTo connect:\r\nURL: [schemeHost]\r\n\r\nUsername: [username] \r\nor email: [email]\r\n\r\nPassword: [password]\r\n\r\nPlease do not respond to this automated email.\r\n\r\nThank you,\r\n[schemeHost]',2,1547406803,2,1585857079),
	(2,1,1,'resetPassword','Password reset','Hi,\r\n\r\nA request was placed to regenerate the password of the account linked to the email [email].\r\n\r\nHere is the new password: [password]\r\n\r\nClick on the following link to activate your new password:\r\n[uri]\r\n\r\nThank you,\r\n[schemeHost]',2,1551155134,4,1585857075),
	(3,1,1,'contactConfirm','Contact','Hi,\r\n\r\nWe have received your email sent from [host].\r\n\r\nThank you,\r\n[host]',2,1580290230,2,1585857101),
	(4,1,1,'contactAdmin','Contact','Hi,\r\n\r\nA contact form has been submitted on [host]\r\n\r\n[data]\r\n\r\nGo to: [link]\r\n\r\nThank you,\r\n[host]',2,1580290251,2,1585857091);

/*!40000 ALTER TABLE `email` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table lang
# ------------------------------------------------------------

DROP TABLE IF EXISTS `lang`;

CREATE TABLE `lang` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) DEFAULT 1,
  `type` text DEFAULT NULL,
  `key` varchar(100) DEFAULT NULL,
  `content_en` text DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `typeKey` (`type`(10),`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

LOCK TABLES `lang` WRITE;
/*!40000 ALTER TABLE `lang` DISABLE KEYS */;

INSERT INTO `lang` (`id`, `active`, `type`, `key`, `content_en`, `userAdd`, `dateAdd`, `userModify`, `dateModify`)
VALUES
	(2,1,'0,1','relation/contextType/app','Application',2,1585856931,NULL,NULL),
	(1,1,'0,1','label','Project - QuidPHP',2,1585857756,2,1585858259);

/*!40000 ALTER TABLE `lang` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table log
# ------------------------------------------------------------

DROP TABLE IF EXISTS `log`;

CREATE TABLE `log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` int(11) DEFAULT NULL,
  `context` varchar(100) DEFAULT NULL,
  `json` text DEFAULT NULL,
  `request` text DEFAULT NULL,
  `session_id` int(11) DEFAULT NULL,
  `userCommit` int(11) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table logCron
# ------------------------------------------------------------

DROP TABLE IF EXISTS `logCron`;

CREATE TABLE `logCron` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `route` varchar(100) DEFAULT NULL,
  `context` varchar(100) DEFAULT NULL,
  `json` text DEFAULT NULL,
  `session_id` int(11) DEFAULT NULL,
  `userCommit` int(11) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table logEmail
# ------------------------------------------------------------

DROP TABLE IF EXISTS `logEmail`;

CREATE TABLE `logEmail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) DEFAULT NULL,
  `context` varchar(100) DEFAULT NULL,
  `json` text DEFAULT NULL,
  `request` text DEFAULT NULL,
  `session_id` int(11) DEFAULT NULL,
  `userCommit` int(11) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table logError
# ------------------------------------------------------------

DROP TABLE IF EXISTS `logError`;

CREATE TABLE `logError` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(11) DEFAULT NULL,
  `context` varchar(100) DEFAULT NULL,
  `error` text DEFAULT NULL,
  `request` text DEFAULT NULL,
  `session_id` int(11) DEFAULT NULL,
  `userCommit` int(11) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table logHttp
# ------------------------------------------------------------

DROP TABLE IF EXISTS `logHttp`;

CREATE TABLE `logHttp` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` int(11) DEFAULT NULL,
  `context` varchar(100) DEFAULT NULL,
  `request` text DEFAULT NULL,
  `json` text DEFAULT NULL,
  `session_id` int(11) DEFAULT NULL,
  `userCommit` int(11) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table logSql
# ------------------------------------------------------------

DROP TABLE IF EXISTS `logSql`;

CREATE TABLE `logSql` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` int(11) DEFAULT NULL,
  `context` varchar(100) DEFAULT NULL,
  `json` text DEFAULT NULL,
  `request` text DEFAULT NULL,
  `session_id` int(11) DEFAULT NULL,
  `userCommit` int(11) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table queueEmail
# ------------------------------------------------------------

DROP TABLE IF EXISTS `queueEmail`;

CREATE TABLE `queueEmail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) DEFAULT NULL,
  `context` varchar(100) DEFAULT NULL,
  `json` text DEFAULT NULL,
  `session_id` int(11) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table redirection
# ------------------------------------------------------------

DROP TABLE IF EXISTS `redirection`;

CREATE TABLE `redirection` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) DEFAULT 1,
  `type` text DEFAULT NULL,
  `key` varchar(100) DEFAULT NULL,
  `value` varchar(100) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `typeKey` (`type`(10),`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table session
# ------------------------------------------------------------

DROP TABLE IF EXISTS `session`;

CREATE TABLE `session` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `envType` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `sid` varchar(100) DEFAULT NULL,
  `data` text DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



# Dump of table user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) DEFAULT 1,
  `role` text DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(250) DEFAULT NULL,
  `passwordReset` varchar(250) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `timezone` int(11) DEFAULT NULL,
  `dateLogin` int(11) DEFAULT NULL,
  `userAdd` int(11) DEFAULT NULL,
  `dateAdd` int(11) DEFAULT NULL,
  `userModify` int(11) DEFAULT NULL,
  `dateModify` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;

INSERT INTO `user` (`id`, `active`, `role`, `username`, `password`, `passwordReset`, `email`, `timezone`, `dateLogin`, `userAdd`, `dateAdd`, `userModify`, `dateModify`)
VALUES
	(1,1,'1','nobody','$2y$10$ywnhcNg.BKj3RpnQ4q0rxOivOO6bCPHhnS.cwwndhxcd4.NjXkyoe',NULL,'nobody@project.com',NULL,NULL,2,1525308766,2,1526831130),
	(2,1,'80','admin','$2y$10$xpSmrVhcL7cnilNkvjbkeuZPknpdKrydj0avHCLWtwH5bI.mE5Ara',NULL,'admin@project.com',NULL,1585857235,2,1525308766,2,1585858020),
	(3,1,'90','cli','$2y$10$ywnhcNg.BKj3RpnQ4q0rxOivOO6bCPHhnS.cwwndhxcd4.NjXkyoe',NULL,'cli@project.com',NULL,NULL,3,1541533337,NULL,NULL);

/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
